const { response } = require("express");
const { Course } = require("../../schema/course.schema");
const { Subject, Branch, SubjectBranch, University } = require("../../schema/subject.schema");
const fs = require('fs');
const { promisify } = require('util');
const unlinkAsync = promisify(fs.unlink);

function transformSentence(sentence) {
  const cleanSentence = sentence.replace(/[^\w\s]/g, '');
  const hyphenatedSentence = cleanSentence.split(' ').join('-');
  return hyphenatedSentence;
}


const createSubject =async (req,res)=>{
    try {
        const { name } = req.body;
        let create = await Subject.create({
          name,
        });

        if (!create) {
          return res.json({ status: 0, message: "Subject Not Created" });
        }

        res.json({ status: 1, message: "Subject created" });
    } catch (error) {
        console.log(error)
    }
}

const createBranch =async (req,res)=>{
    try {
        const { name } = req.body;
        let create = await Branch.create({
          name: name,
        });

        if (!create) {
          return res.json({ status: 0, message: "Branch Not Created" });
        }
        res.json({ status: 1, message: "Branch created" });
    } catch (error) {
        console.log(error)
    }
}


const createSubjectBranch =async (req,res)=>{
    try {
        const { subjectId,branches } = req.body;

        if(branches.length<=0){
            return res.json({status:0,message:"No Branches Added"})
        }

        if(!subjectId){
            return res.json({status:0,message:"No Subject Selected"})
        }



        let create = await SubjectBranch.create({
          subjectId:subjectId,
          subBranches:branches
        });

        if(!create){
            return res.json({status:0,message:"Subject Branch Not Created"})
        }

        res.json({status:1,message:"Subject Branch created"})
    } catch (error) {
        console.log(error)
    }
}

const createCourse =async (req,res)=>{
    try {
        const {title,universityId,location,rank,fees,duration,score,description,subjectId,branchId,country,qualification} = req.body;

        let create = await Course.create({
          title,
          universityId,
          location,
          rank,
          fees,
          duration,
          score,
          description,
          subjectId,
          branchId,
          country,
          qualification
        });

        if(!create){
            return res.json({status:0,message:"Course Not Created"})
        }

        res.json({status:1,message:"Course created"})
    } catch (error) {
        console.log(error)
    }
}

const updateCourse =async (req,res)=>{
    try {
        const {_id,title,universityId,location,rank,fees,duration,score,description,subjectId,branchId,country,qualification} = req.body;

        let update = await Course.findByIdAndUpdate({_id:_id},{$set:{
        title,
          universityId,
          location,
          rank,
          fees,
          duration,
          score,
          description,
          subjectId,
          branchId,
          country,
          qualification
        }});

        if (!update) {
            return res.json({ status: 0, message: "Course Not Updated" });
          }

        res.json({status:1,message:"Course Updated"})
    } catch (error) {
        console.log(error)
    }
}

const removeCourse =async(req,res)=>{
    try {
        const {courseId}=req.body
        if(!courseId){
            return res.json({status:0,message:"Course ID required"})
        }

        const remove = await Course.findByIdAndDelete({_id:courseId})
        if(!remove){
            return res.json({status:0,message:"Course not Removed"})
        }
        res.json({status:1,message:"Course is Removed"})
    } catch (error) {
        console.log(error)
    }
}

const editSubject =async (req,res)=>{
    try {
        const { name,subjectId } = req.body;
        let update = await Subject.findByIdAndUpdate({_id:subjectId},{$set:{name:name}})

        if (!update) {
          return res.json({ status: 0, message: "Subject Not Updated" });
        }

        res.json({ status: 1, message: "Subject Updated" });
    } catch (error) {
        console.log(error)
    }
}


const editBranch =async (req,res)=>{
    try {
        const { name,branchId } = req.body;
        let update = await Branch.findByIdAndUpdate({_id:branchId},{$set:{name:name}})

        if (!update) {
          return res.json({ status: 0, message: "Branch Not Updated" });
        }

        res.json({ status: 1, message: "Branch Updated" });
    } catch (error) {
        console.log(error)
    }
}


const removeSubject =async(req,res)=>{
    try {
        const {subjectId}=req.body
        if(!subjectId){
            return res.json({status:0,message:"Blog ID required"})
        }

        const remove = await Subject.findByIdAndDelete({_id:subjectId})
        if(!remove){
            return res.json({status:0,message:"Subject not Removed"})
        }
        res.json({status:1,message:"Subject is Removed"})
    } catch (error) {
        console.log(error)
    }
}

const removeBranch =async(req,res)=>{
    try {
        const {branchId}=req.body
        if(!branchId){
            return res.json({status:0,message:"Branch ID required"})
        }

        const remove = await Branch.findByIdAndDelete({_id:branchId})
        if(!remove){
            return res.json({status:0,message:"Branch not Removed"})
        }
        res.json({status:1,message:"Branch is Removed"})
    } catch (error) {
        console.log(error)
    }
}



const getAllSubject = async (req, res) => {
    try {
      const { search = '', active = '', fromDate = '', toDate = '', limit = 25, skip = 0 } = req.body;
      let query = [];
  
      if (search !== '') {
        query.push({
          $match: {
            $or: [
              { name: { $regex: search + '.*', $options: 'si' } },
            ]
          }
        });
      }
  
      if (active !== '') {
        query.push({ $match: { isActive: active } });
      }
  
  
      query.push({ $sort: { createdAt: -1 } });
  
      const documentQuery = [
        ...query,
        { $skip: parseInt(skip) },
        { $limit: parseInt(limit) },
        {
          $project: {
            name:1,
            createdAt: 1,
            updatedAt: 1,
          }
        }
      ];
  
      const overallQuery = [
        ...query,
        { $count: 'counts' }
      ];
  
      const finalquery = [
        {
          $facet: {
            overall: overallQuery,
            documentdata: documentQuery
          }
        }
      ];
  
      const subjectData = await Subject.aggregate(finalquery);
      let data = subjectData[0].documentdata || [];
      let fullCount = subjectData[0].overall[0] ? subjectData[0].overall[0].counts : 0;
  
      if (data.length > 0) {
        res.json({
          status: 1,
          response: {
            result: data,
            fullcount: fullCount,
            length: data.length,
          }
        });
      } else {
        res.json({
          status: 0,
          response: {
            result: [],
            fullcount: fullCount,
            length: 0,
          }
        });
      }
    } catch (error) {
      console.log(error);
      res.status(500).json({ status: 0, message: "Internal server error" });
    }
  };

  const clientSideSubjectList =async(req,res)=>{
    try {
      const allSubject=await Subject.find()
      if(!allSubject){
        return res.json({status:0,message:'No subject found'})
      }
      res.json({status:1,response:allSubject})
    } catch (error) {
      console.log(error)
    }
  }

const clientSideBranchList =async(req,res)=>{
  try {
    const allBranch = Branch.find().sort({name:1})
    if(!allBranch){
     return res.json({status:0,response:{result:[]}})
    }
      res.json({status:1,response:allBranch})
  } catch (error) {
    console.log(error)
  }
}

  const getAllBranch = async (req, res) => {
    try {
      const { search = '', active = '', fromDate = '', toDate = '', limit = 25, skip = 0 } = req.body;
      let query = [];
  
      if (search !== '') {
        query.push({
          $match: {
            $or: [
              { name: { $regex: search + '.*', $options: 'si' } },
            ]
          }
        });
      }
  
      if (active !== '') {
        query.push({ $match: { isActive: active } });
      }
  
  
      query.push({ $sort: { createdAt: -1 } });
  
      const documentQuery = [
        ...query,
        { $skip: parseInt(skip) },
        { $limit: parseInt(limit) },
        {
          $project: {
            name:1,
            createdAt: 1,
            updatedAt: 1,
          }
        }
      ];
  
      const overallQuery = [
        ...query,
        { $count: 'counts' }
      ];
  
      const finalquery = [
        {
          $facet: {
            overall: overallQuery,
            documentdata: documentQuery
          }
        }
      ];
  
      const branchData = await Branch.aggregate(finalquery);
      let data = branchData[0].documentdata || [];
      let fullCount = branchData[0].overall[0] ? branchData[0].overall[0].counts : 0;
  
      if (data.length > 0) {
        res.json({
          status: 1,
          response: {
            result: data,
            fullcount: fullCount,
            length: data.length,
          }
        });
      } else {
        res.json({
          status: 0,
          response: {
            result: [],
            fullcount: fullCount,
            length: 0,
          }
        });
      }
    } catch (error) {
      console.log(error);
      res.status(500).json({ status: 0, message: "Internal server error" });
    }
  };

  const getAllCourse = async (req, res) => {
    try {
      const { search = '', active = '',country=[],qualification=[],subject=[],fromDate = '', toDate = '', limit = 25, skip = 0 } = req.body;
      let query = [];
  
      if (search !== '') {
        query.push({
          $match: {
            $or: [
              { title: { $regex: search + '.*', $options: 'si' } },
              { university: { $regex: search + '.*', $options: 'si' } },
              { location: { $regex: search + '.*', $options: 'si' } },
              { country: { $regex: search + '.*', $options: 'si' } },
            ]
          }
        });
      }
  
      if (active !== '') {
        query.push({ $match: { isActive: active } });
      }

      if(country?.length>0){
        query.push({ $match: { country: { $in: country } } });
      }

      if(qualification.length>0){
        query.push({ $match: { qualification: { $in: qualification } } });
      }

      query.push({
        $lookup:{
          from: 'universities',
          localField: 'universityId',
          foreignField: '_id',
          as: 'universityDetails'
        },
      },
      {
        $unwind: { path: '$universityDetails', preserveNullAndEmptyArrays: true },
      })

      query.push({
        $lookup:{
          from: 'subjects',
          localField: 'subjectId',
          foreignField: '_id',
          as: 'subjectDetails'
        },
      },
      {
        $unwind: { path: '$subjectDetails', preserveNullAndEmptyArrays: true },
      })
  
  
      query.push({ $sort: { createdAt: -1 } });
  
      const documentQuery = [
        ...query,
        { $skip: parseInt(skip) },
        { $limit: parseInt(limit) },
        {
          $project: {
            title:1,
            universityId:1,
            universityDetails:1,
            location:1,
            rank:1,
            fees:1,
            duration:1,
            score:1,
            description:1,
            subjectId:1,
            branchId:1,
            country:1,
            qualification:1,
            createdAt: 1,
            updatedAt: 1,
            subjectDetails:1
          }
        }
      ];
  
      const overallQuery = [
        ...query,
        { $count: 'counts' }
      ];
  
      const finalquery = [
        {
          $facet: {
            overall: overallQuery,
            documentdata: documentQuery
          }
        }
      ];
  
      const courseData = await Course.aggregate(finalquery);
      let data = courseData[0].documentdata || [];
      let fullCount = courseData[0].overall[0] ? courseData[0].overall[0].counts : 0;
  
      if (data.length > 0) {
        res.json({
          status: 1,
          response: {
            result: data,
            fullcount: fullCount,
            length: data.length,
          }
        });
      } else {
        res.json({
          status: 0,
          response: {
            result: [],
            fullcount: fullCount,
            length: 0,
          }
        });
      }
    } catch (error) {
      console.log(error);
      res.status(500).json({ status: 0, message: "Internal server error" });
    }
  };

  const getCourseDetails = async(req,res)=>{
    try {
      const {courseId}=req.body

      const courseDetails = await Course.findById(courseId).populate('universityId')
      if(!courseDetails){
        return res.json({status:0,message:"Course not found"})
      }
      res.json({status:1,response:courseDetails})
    } catch (error) {
      console.log(error)
    }
  }

const getSubjects = async(req,res)=>{
    try {
        const data = await Subject.find({isActive:{$ne:false}})
        if(!data){
            return res.json({status:0,message:"data not found"})
        }
        res.json({status:1,response:data})
    } catch (error) {
        console.log(error)
    }
}

const getBranches = async(req,res)=>{
    try {
        const data = await Branch.find({isActive:{$ne:false}})
        if(!data){
            return res.json({status:0,message:"data not found"})
        }
        res.json({status:1,response:data})
    } catch (error) {
        console.log(error)
    }
}

const createUniversity =async (req,res)=>{
  try {
    const getAttachment = (path, name) => encodeURI(path.substring(2) + name);
    const { name,country,location,details,students,rank,costOfLiving } = req.body;

    let images=[]
    if(req.files.images){
      req.files.images.map((e) => {
        images.push(getAttachment(e.destination, e.filename));
      });
    }

      let uniId=transformSentence(name)
      let currency = JSON.parse(req.body.currency)
      let create = await University.create({
        name,
        country,location,currency,uniId,images,details,students,rank,costOfLiving
      });

      if (!create) {
        return res.json({ status: 0, message: "University Not Created" });
      }

      res.json({ status: 1, message: "UNiversity created" });
  } catch (error) {
      console.log(error)
  }
}

const updateUniversity =async (req,res)=>{
  try {
    const {_id,name,country,location,details,students,rank,costOfLiving } = req.body;
    const getAttachment = (path, name) => encodeURI(path.substring(2) + name);

      if(req.body.removedImages&&req.body?.removedImages?.length>0){
        let removedImages = JSON.parse(req.body.removedImages)

       for(let img of removedImages){
        unlinkAsync(img)
        .then((resolved) => {
         console.log('Photo removed')
        })
        .catch((error) => {
          console.log('error', error);
        });
       }
       
      }

      let updatedImages = JSON.parse(req.body.images)??[]
      let editCurrency =JSON.parse(req.body.currency)
      if(req.files.newImages){
        req.files.newImages.map((e) => {
          updatedImages.push(getAttachment(e.destination, e.filename));
        });
      }


      let uniId = transformSentence(name)

      let update = await University.findByIdAndUpdate({_id:_id},{$set:{
        name,
        currency:editCurrency,
        location,
        country,
        uniId,
        rank,
        details,
        students,
        costOfLiving,
        images:updatedImages
      }});

      if (!update) {
          return res.json({ status: 0, message: "University Not Updated" });
        }

      res.json({status:1,message:"University Updated"})
  } catch (error) {
      console.log(error)
  }
}

const removeUniversity =async(req,res)=>{
  try {
      const {universityId}=req.body
      if(!universityId){
          return res.json({status:0,message:"university ID required"})
      }

      const remove = await University.findByIdAndDelete({_id:universityId})
      if(!remove){
          return res.json({status:0,message:"university not Removed"})
      }
      res.json({status:1,message:"Branch is Removed"})
  } catch (error) {
      console.log(error)
  }
}

const getAllUniversity = async (req, res) => {
  try {
    const { search = '', active = '',country,fromDate = '', toDate = '', limit = 25, skip = 0 } = req.body;
    let query = [];

    if (search !== '') {
      query.push({
        $match: {
          $or: [
            { name: { $regex: search + '.*', $options: 'si' } },
            { location: { $regex: search + '.*', $options: 'si' } },
            { country: { $regex: search + '.*', $options: 'si' } },
          ]
        }
      });
    }

    if (active !== '') {
      query.push({ $match: { isActive: active } });
    }

    if(country){
      query.push({ $match: { country: country } });
    }

    


    query.push({ $sort: { createdAt: -1 } });

    const documentQuery = [
      ...query,
      { $skip: parseInt(skip) },
      { $limit: parseInt(limit) },
      {
        $project: {
          name:1,
          location:1,
          country:1,
          currency:1,
          createdAt: 1,
          updatedAt: 1,
          images:1,
          students:1,
          rank:1,
          details:1,
          costOfLiving:1
        }
      }
    ];

    const overallQuery = [
      ...query,
      { $count: 'counts' }
    ];

    const finalquery = [
      {
        $facet: {
          overall: overallQuery,
          documentdata: documentQuery
        }
      }
    ];

    const universityData = await University.aggregate(finalquery);
    let data = universityData[0].documentdata || [];
    let fullCount = universityData[0].overall[0] ? universityData[0].overall[0].counts : 0;

    if (data.length > 0) {
      res.json({
        status: 1,
        response: {
          result: data,
          fullcount: fullCount,
          length: data.length,
        }
      });
    } else {
      res.json({
        status: 0,
        response: {
          result: [],
          fullcount: fullCount,
          length: 0,
        }
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ status: 0, message: "Internal server error" });
  }
};

const getUniversities = async(req,res)=>{
  try {
      const data = await University.find({isActive:{$ne:false}})
      if(!data){
          return res.json({status:0,message:"data not found"})
      }
      res.json({status:1,response:data})
  } catch (error) {
      console.log(error)
  }
}

const getUniversityDetails =async(req,res)=>{
  try {
    const {universityId}=req.body
    if(!universityId){
      return res.json({status:0,message:"University Id Required"})
    }

    const getUniversity = await University.findById({_id:universityId})
    if(!getUniversity){
      return res.json({status:0,message:"University Not Found"})
    }
    res.json({status:1,response:getUniversity})
  } catch (error) {
    console.log(error)
  }
}

const getAllSearchList = async (req, res) => {
  try {
    const { search, filterBy } = req.body;

    // Optional: Find matching subject and branch IDs (if search is a name)
    const subjectMatches = await Subject.find({ name: { $regex: search, $options: "i" } });
    const branchMatches = await Branch.find({ name: { $regex: search, $options: "i" } });

    const subjectIds = subjectMatches.map(s => s._id);
    const branchIds = branchMatches.map(b => b._id);

    // Initialize empty results
    let courseResults = [], universityResults = [], subjectResults = [];

    // Run queries based on filterBy
    if (!filterBy || filterBy === "courses") {
      courseResults = await Course.find({
        $or: [
          { title: { $regex: search, $options: "i" } },
          { subjectId: { $in: subjectIds } },
          { branchId: { $in: branchIds } }
        ]
      }).populate('subjectId').populate('branchId').populate('universityId');
    }

    if (!filterBy || filterBy === "universities") {
      universityResults = await University.find({
        name: { $regex: search, $options: "i" }
      });
    }

    if (!filterBy || filterBy === "subjects") {
      subjectResults = await Subject.find({
        name: { $regex: search, $options: "i" }
      });
    }

    // Counts
    const courseCount = courseResults.length;
    const universityCount = universityResults.length;
    const subjectCount = subjectResults.length;
    const totalCount = courseCount + universityCount + subjectCount;

    const finalResult = {
      courses: courseResults,
      universities: universityResults,
      subjects: subjectResults,
      count: {
        courses: courseCount,
        universities: universityCount,
        subjects: subjectCount,
        total: totalCount
      }
    };

    res.json({ status: 1, response: finalResult });

  } catch (error) {
    console.log(error);
    res.status(500).json({ status: 0, message: "Internal server error" });
  }
};



module.exports = {
  createSubject,
  createBranch,
  createSubjectBranch,
  getAllSubject,
  getAllBranch,
  editSubject,
  editBranch,
  removeSubject,
  removeBranch,
  getSubjects,
  getBranches,
  createCourse,
  getAllCourse,
  getCourseDetails,
  updateCourse,
  removeCourse,
  createUniversity,
  updateUniversity,
  removeUniversity,
  getAllUniversity,
  getUniversities,
  getUniversityDetails,
  clientSideBranchList,
  clientSideSubjectList,
  getAllSearchList
};